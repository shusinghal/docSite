## Find sum of two integer numbers

```
 int1 = input('Enter first integer: ') 
 int2 = input('Enter second integer: ')

 sum = int(int1) + int(int2)

 print('The sum of {0} and {1} is {2}'.format(int1, int2, sum))
```
## Output

```
Enter first integer: 11
Enter second integer: 22
The sum of 11 and 22 is 33
```