# Introduction to NASA
NASA – or the National Aeronautics and Space Administration, to give it its full name – is an American government agency focused on space exploration, aero-nautics, and aerospace research. <br> <p> <p> 

# SCOPE oF this DOCUMENT

Most developers getting started with api.nasa.gov wish to leverage NASA data in their applications and services, and this is encouraged. There are also developers that have existing APIs that they may wish to contribute to the NASA API site.<br>*This document consists of the only API documentation for NASA APOD (NASA Astronomy Picture of Day)*. 

