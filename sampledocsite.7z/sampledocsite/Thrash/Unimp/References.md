# API REFERENCE

This  is a REST (Representational State Transfer) API.
This API has predictable, resource oriented URLs, and uses HTTP response codes to indicate API errors. <p>
>URL: api.nasa.gov/planetary/apod 

>**API Root / Base URI** : <p>
https://api.nasa.gov

>**API resources**: <p>/planetary/apod

<p>&nbsp;</p>

## HTTP status code summary


<p>&nbsp;</p>


| Code   | Summary |
| ------------- | ------------- |
| **200** <p> *OK*    | Everything worked as expected.  |
| **400**<p> *Bad Request*  | The request was unacceptable, often due to missing a required parameter. |
| **500, 502, 503, 504**  <p>  *Server Errors* | ESomething went wrong on the API's end. 

<p>&nbsp;</p>

##  Types of Request and Description

| Request   | Description |
| ------------- | ------------- |
| **GET** <p>    | Use GET requests to retrieve resource representation/information only – and not to modify it in any way. As GET requests do not change the state of the resource, these are said to be safe methods. Additionally, GET APIs should be idempotent, which means that making multiple identical requests must produce the same result every time until another API (POST or PUT) has changed the state of the resource on the server.  |
| **POST**<p>  | Use POST requests to create new subordinate resources, e.g., a file is subordinate to a directory containing it or a row is subordinate to a database table. When talking strictly in terms of REST, POST methods are used to create a new resource into the collection of resources. | <p>&nbsp;</p>
| **DELETE**<p>  | Use DELETE requests to delete resources, e.g., a file is subordinate to a directory containing it or a row is subordinate to a database table. When talking strictly in terms of REST, POST methods are used to create a new resource into the collection of resources. | <p>&nbsp;</p>