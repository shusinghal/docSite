# Example of  Request and Response<p>

## HTTP Request 

### Steps to  make a request. <p>&nbsp;</p>

1. Create a new request.
2. Save the request in the desired folder 
3. Select the request type as GET.
4. Enter the URL of the API in the search box beside the  request field.
5. Check the Authorisation code and and then proceed. 
5. Click Search <p>&nbsp;</p>

| Request   |  |
| ------------- | ------------- |
| **GET** <p>    | https://api.nasa.gov/planetary/apod?api_key=NNKOjkoul8n1CH18TWA9gwngW1s1SmjESPjNoUFo|



| Response   |  |
| ------------- | ------------- |
| **Status** <p>    | Status 	200 OK

Body </p> </p>	{
    "**date**": "2019-05-02",<pr>
    "explanation": "Orbiting 400 kilometers above Quebec, Canada, planet Earth, the International Space Station Expedition 59 crew captured this snapshot of the broad St. Lawrence River and curiously circular Lake Manicouagan on April 11. Right of center, the ring-shaped lake is a modern reservoir within the eroded remnant of an ancient 100 kilometer diameter impact crater. The ancient crater is very conspicuous from orbit, a visible reminder that Earth is vulnerable to rocks from space. Over 200 million years old, the Manicouagan crater was likely caused by the impact of a rocky body about 5 kilometers in diameter.  Currently, there is no known asteroid with a significant probability of impacting Earth in the next century.  But a fictional scenario to help practice for an asteroid impact is on going at the 2019 IAA Planetary Defense Conference.",
    "hdurl": "https://apod.nasa.gov/apod/image/1905/iss059e019043.jpg",
    "**media_type**": "image",
    "**service_version**": "v1",
    "title": "Manicouagan Impact Crater from Space",
    "url": "https://apod.nasa.gov/apod/image/1905/iss059e019043_1024.jpg"
             }
|
