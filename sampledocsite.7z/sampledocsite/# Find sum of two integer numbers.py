# Find sum of two integer numbers
int1 = input('Enter first integer: ')
int2 = input('Enter second integer: ')

# Add two integer numbers
sum = int(int1) + int(int2)

# Show the sum
print('The sum of {0} and {1} is {2}'.format(int1, int2, sum))